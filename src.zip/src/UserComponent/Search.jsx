import React from 'react'

const Search = () => {
    return (
        <div className="search">
            <h3>Search</h3>
            
        </div>
    )
}

export default Search
