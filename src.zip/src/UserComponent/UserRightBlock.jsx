import React from 'react'

const UserRightBlock = () => {
    return (
        <div className="userRightBlock">
            <h1>Right</h1>
        </div>
    )
}

export default UserRightBlock
