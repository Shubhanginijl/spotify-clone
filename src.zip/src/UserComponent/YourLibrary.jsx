import React from 'react'

const YourLibrary = () => {
    return (
        <div className="library">
            <h3>Your Library</h3>
        </div>
    )
}

export default YourLibrary
